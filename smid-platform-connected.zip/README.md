# SMID Platform - Connected System

## Files Overview

### Frontend (GitHub Pages)
- `index.html` - Landing page
- `login.html` - Authentication (SMID In / SMID Out)
- `dashboard.html` - Protected user dashboard
- `prototype.html`, `register.html`, `idcard.html`, `cloud.html`, `founder.html` - Placeholder pages
- `shared.js` - Core auth system, route guards, theme, notifications
- `styles.css` - Your existing stylesheet (not included, add your own)

### Backend (FastAPI)
- `main.py` - Secure API with bcrypt hashing, JWT tokens, CORS
- `requirements.txt` - Python dependencies

## Setup

### 1. Backend (Local)
```bash
pip install -r requirements.txt
uvicorn main:app --reload
```
Backend runs at: `http://127.0.0.1:8000`

### 2. Frontend (Local)
Open `login.html` in a live server (VS Code Live Server, etc.)

### 3. Connect Frontend to Backend
Edit `shared.js` line 3:
```javascript
const API_BASE_URL = 'http://127.0.0.1:8000';  // Local
// OR
const API_BASE_URL = 'https://your-backend.onrender.com';  // Production
```

### 4. Deploy Backend
Deploy `main.py` + `requirements.txt` to:
- Render (render.com)
- Railway (railway.app)
- Heroku
- Any cloud provider

### 5. Deploy Frontend
Upload all HTML + `shared.js` + `styles.css` to GitHub Pages.

## Security Features
- Passwords hashed with bcrypt (never stored plain)
- JWT tokens with 1-hour expiry
- sessionStorage (auto-clears on tab close)
- Route guards on protected pages
- CORS restricted to your domain
- No local password storage

## Important
- Update `origins` in `main.py` with your actual GitHub Pages URL
- Change `JWT_SECRET` environment variable in production
- Add `styles.css` to the folder (not generated - use your existing one)
