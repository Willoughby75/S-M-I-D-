// ---------- SECURE AUTH SYSTEM ----------
// UPDATE THIS: Point to your deployed FastAPI backend (Render, Heroku, Railway, etc.)
// Local dev: http://127.0.0.1:8000
const API_BASE_URL = 'https://api.your-smid-backend.com'; 

const SMIDAuth = {
    async signup(name, email, password) {
        if (!name || !email || !password) {
            showNotification('Error', 'Please fill all fields', 'error');
            return false;
        }
        if (password.length < 6) {
            showNotification('Error', 'Password must be at least 6 characters', 'error');
            return false;
        }

        try {
            const response = await fetch(`${API_BASE_URL}/register`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, email, password })
            });

            const data = await response.json();

            if (!response.ok) {
                showNotification('Error', data.message || 'Registration failed', 'error');
                return false;
            }

            showNotification('Success', `Welcome, ${name}! Your account has been created. Please login.`, 'success');
            setTimeout(() => switchAuthTab('smidin'), 1500);
            return true;

        } catch (error) {
            console.error("Signup Error:", error);
            showNotification('Error', 'Server error. Please try again later.', 'error');
            return false;
        }
    },

    async login(email, password) {
        if (!email || !password) {
            showNotification('Error', 'Please fill all fields', 'error');
            return false;
        }

        try {
            const response = await fetch(`${API_BASE_URL}/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });

            const data = await response.json();

            if (!response.ok) {
                showNotification('Error', data.message || 'Invalid credentials', 'error');
                return false;
            }

            sessionStorage.setItem('smid_token', data.token);
            sessionStorage.setItem('smid_current_user', JSON.stringify(data.user));

            showNotification('Success', `Welcome back, ${data.user.name}!`, 'success');
            updateAuthNav();

            setTimeout(() => window.location.href = 'dashboard.html', 1000);
            return true;

        } catch (error) {
            console.error("Login Error:", error);
            showNotification('Error', 'Server error. Please try again later.', 'error');
            return false;
        }
    },

    logout() {
        sessionStorage.removeItem('smid_token');
        sessionStorage.removeItem('smid_current_user');
        showNotification('Info', 'You have been logged out.', 'info');
        updateAuthNav();
        setTimeout(() => window.location.href = 'index.html', 500);
    },

    getUser() {
        return JSON.parse(sessionStorage.getItem('smid_current_user') || 'null');
    },

    getToken() {
        return sessionStorage.getItem('smid_token');
    },

    isLoggedIn() {
        return !!this.getToken();
    }
};

// ---------- SECURE PAGE INIT & ROUTE GUARD ----------
function enforceSecurityGuard() {
    const protectedPages = ['dashboard.html', 'idcard.html', 'cloud.html'];
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';

    if (protectedPages.includes(currentPage) && !SMIDAuth.isLoggedIn()) {
        window.location.replace('login.html');
        return false;
    }

    const authPages = ['login.html'];
    if (authPages.includes(currentPage) && SMIDAuth.isLoggedIn()) {
        window.location.replace('dashboard.html');
        return false;
    }
    return true;
}

function updateAuthNav() {
    const user = SMIDAuth.getUser();
    const navLinks = document.querySelector('.nav-links');
    if (!navLinks) return;

    // Remove existing auth links
    const existingAuth = navLinks.querySelectorAll('.auth-nav-item');
    existingAuth.forEach(el => el.remove());

    if (SMIDAuth.isLoggedIn() && user) {
        const logoutBtn = document.createElement('a');
        logoutBtn.href = '#';
        logoutBtn.className = 'auth-nav-item';
        logoutBtn.textContent = `Logout (${user.name})`;
        logoutBtn.onclick = (e) => { e.preventDefault(); SMIDAuth.logout(); };
        navLinks.appendChild(logoutBtn);
    } else {
        const loginBtn = document.createElement('a');
        loginBtn.href = 'login.html';
        loginBtn.className = 'auth-nav-item';
        loginBtn.textContent = 'Login';
        navLinks.appendChild(loginBtn);
    }
}

function initPage() {
    if (!enforceSecurityGuard()) return; 
    loadTheme();
    updateAuthNav();

    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('.nav-links a, .mobile-menu a').forEach(link => {
        const href = link.getAttribute('href');
        if (href === currentPage || (currentPage === '' && href === 'index.html')) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
}

// ---------- THEME SYSTEM ----------
function loadTheme() {
    const savedTheme = localStorage.getItem('smid_theme') || 'dark';
    document.body.setAttribute('data-theme', savedTheme);
}

function setTheme(theme) {
    document.body.setAttribute('data-theme', theme);
    localStorage.setItem('smid_theme', theme);
}

// ---------- NOTIFICATIONS ----------
function showNotification(title, message, type = 'info') {
    const container = document.getElementById('notificationContainer');
    if (!container) return;

    const notif = document.createElement('div');
    notif.className = `notification ${type}`;
    notif.innerHTML = `<strong>${title}</strong><p>${message}</p>`;
    container.appendChild(notif);

    setTimeout(() => notif.remove(), 4000);
}

// ---------- MOBILE MENU ----------
function toggleMobileMenu() {
    document.getElementById('mobileMenu').classList.toggle('active');
}

// ---------- PASSWORD STRENGTH ----------
function checkPasswordStrength(password) {
    const strengthBar = document.getElementById('pwStrength');
    const strengthLabel = document.getElementById('pwLabel');
    if (!strengthBar || !strengthLabel) return;

    let strength = 0;
    if (password.length >= 6) strength++;
    if (password.length >= 10) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[^A-Za-z0-9]/.test(password)) strength++;

    const colors = ['#ff4444', '#ff8844', '#ffaa44', '#44aa44', '#00cc44'];
    const labels = ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong'];

    strengthBar.style.width = `${(strength / 5) * 100}%`;
    strengthBar.style.backgroundColor = colors[strength - 1] || '#ff4444';
    strengthLabel.textContent = labels[strength - 1] || 'Enter password';
}

document.addEventListener('DOMContentLoaded', initPage);
